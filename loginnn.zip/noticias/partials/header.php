<header>
    <nav>
        <ul>
            <li><a href="index.php">Inicio</a></li>
            <li><a href="anadir_noticia.php">Añadir Noticia</a></li>
            <li><a href="login.php">Login</a></li>
        </ul>
    </nav>
</header>