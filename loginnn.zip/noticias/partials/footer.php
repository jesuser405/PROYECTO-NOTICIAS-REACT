<footer>
    <a href="index.php">Inicio</a>
    <a href="anadir_noticia.php">Añadir Noticias</a>
    <div class="copyright">&copy; 2025 Curso Nascor</div>
</footer>